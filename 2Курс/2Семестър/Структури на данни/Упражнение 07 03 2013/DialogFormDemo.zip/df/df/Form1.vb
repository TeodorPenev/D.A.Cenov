﻿Public Class Form1

    Private Sub btAdd_Click(sender As System.Object, e As System.EventArgs) Handles btAdd.Click
        Dim dialog As New frmDanni ' Създава променлива 
        Dim r As DialogResult
        dialog.Text = "Добавяне" ' Промяна на надписа на формата
        r = dialog.ShowDialog
        ' Ако резултатът е OK
        If r = Windows.Forms.DialogResult.OK Then
            ' Взема данните от диалога и ги добавя в списъка
            lxImena.Items.Add(dialog.tbIme.Text)
        End If
    End Sub

    Private Sub btEdit_Click(sender As Object, e As System.EventArgs) Handles btEdit.Click
        Dim dialog As New frmDanni ' Създава променлива 
        Dim r As DialogResult
        dialog.Text = "Редактиране" ' Промяна на надписа на формата
        dialog.BackColor = Color.Blue ' Промяна и нейния цвят
        If lxImena.SelectedIndex > -1 Then 'Има избран елемент!
            ' Прехвърляне КЪМ диалоговия прозорец стойноста на избрания
            ' елемент
            dialog.tbIme.Text = lxImena.Items(lxImena.SelectedIndex)
            r = dialog.ShowDialog
            If r = Windows.Forms.DialogResult.OK Then
                ' Промяна стойност на елемент! (не добавяне!)
                lxImena.Items(lxImena.SelectedIndex) = dialog.tbIme.Text
            End If
        Else
            MessageBox.Show("Моля изберете елемент!", "Няма избран елемент", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub
    ' Изтрива избрания елемент
    Private Sub btDelete_Click(sender As Object, e As System.EventArgs) Handles btDelete.Click
        If lxImena.SelectedIndex > -1 Then 'Има избран елемент!
            'Изтрива елемента по номер *RemoveAt
            lxImena.Items.RemoveAt(lxImena.SelectedIndex)
        Else
            MessageBox.Show("Моля изберете елемент!", "Няма избран елемент", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub
    ' Изтрива всички елементи
    Private Sub BtClear_Click(sender As Object, e As System.EventArgs) Handles BtClear.Click
        Dim r As DialogResult
        r = MessageBox.Show("Сигурен ли сте?", "Изтриване", MessageBoxButtons.YesNo, MessageBoxIcon.Error)
        If r = Windows.Forms.DialogResult.Yes Then
            lxImena.Items.Clear()
        End If
    End Sub
    ' Изход
    ' NB!: Проверката се извършва при събитието затвaряне на формата!
    Private Sub BTexit_Click(sender As Object, e As System.EventArgs) Handles BTexit.Click
        Me.Close()
    End Sub

    ' Събитие настъпващо при затваряне на формата
    ' NB! Това събитие настъпва при ВСИЧКИ начини на затваряне на формата! 
    ' Не само при натискане на бутона Изход!
    Private Sub Form1_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim r As DialogResult
        r = MessageBox.Show("Сигурен ли сте?", "Изход", MessageBoxButtons.YesNo, MessageBoxIcon.Error)
        ' Ако е отговoрил с NO
        If r = Windows.Forms.DialogResult.No Then
            ' Забранява затварянето на формата!
            e.Cancel = True
        End If
    End Sub
End Class
