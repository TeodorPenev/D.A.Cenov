﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDanni
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tbIme = New System.Windows.Forms.TextBox()
        Me.lbIme = New System.Windows.Forms.Label()
        Me.btOK = New System.Windows.Forms.Button()
        Me.btCancel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'tbIme
        '
        Me.tbIme.Location = New System.Drawing.Point(50, 6)
        Me.tbIme.Name = "tbIme"
        Me.tbIme.Size = New System.Drawing.Size(247, 20)
        Me.tbIme.TabIndex = 0
        '
        'lbIme
        '
        Me.lbIme.AutoSize = True
        Me.lbIme.Location = New System.Drawing.Point(12, 9)
        Me.lbIme.Name = "lbIme"
        Me.lbIme.Size = New System.Drawing.Size(32, 13)
        Me.lbIme.TabIndex = 1
        Me.lbIme.Text = "Име:"
        '
        'btOK
        '
        Me.btOK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.btOK.Location = New System.Drawing.Point(33, 38)
        Me.btOK.Name = "btOK"
        Me.btOK.Size = New System.Drawing.Size(111, 31)
        Me.btOK.TabIndex = 2
        Me.btOK.Text = "OK"
        Me.btOK.UseVisualStyleBackColor = True
        '
        'btCancel
        '
        Me.btCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btCancel.Location = New System.Drawing.Point(186, 38)
        Me.btCancel.Name = "btCancel"
        Me.btCancel.Size = New System.Drawing.Size(111, 31)
        Me.btCancel.TabIndex = 3
        Me.btCancel.Text = "Отказ"
        Me.btCancel.UseVisualStyleBackColor = True
        '
        'frmDanni
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(318, 87)
        Me.Controls.Add(Me.btCancel)
        Me.Controls.Add(Me.btOK)
        Me.Controls.Add(Me.lbIme)
        Me.Controls.Add(Me.tbIme)
        Me.Name = "frmDanni"
        Me.Text = "frmDanni"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tbIme As System.Windows.Forms.TextBox
    Friend WithEvents lbIme As System.Windows.Forms.Label
    Friend WithEvents btOK As System.Windows.Forms.Button
    Friend WithEvents btCancel As System.Windows.Forms.Button
End Class
