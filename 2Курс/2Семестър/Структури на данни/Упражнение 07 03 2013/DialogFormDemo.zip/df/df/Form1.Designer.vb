﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lxImena = New System.Windows.Forms.ListBox()
        Me.btAdd = New System.Windows.Forms.Button()
        Me.btEdit = New System.Windows.Forms.Button()
        Me.btDelete = New System.Windows.Forms.Button()
        Me.BtClear = New System.Windows.Forms.Button()
        Me.BTexit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lxImena
        '
        Me.lxImena.FormattingEnabled = True
        Me.lxImena.Location = New System.Drawing.Point(14, 25)
        Me.lxImena.Name = "lxImena"
        Me.lxImena.Size = New System.Drawing.Size(176, 134)
        Me.lxImena.TabIndex = 0
        '
        'btAdd
        '
        Me.btAdd.Location = New System.Drawing.Point(196, 25)
        Me.btAdd.Name = "btAdd"
        Me.btAdd.Size = New System.Drawing.Size(86, 56)
        Me.btAdd.TabIndex = 1
        Me.btAdd.Text = "Добави"
        Me.btAdd.UseVisualStyleBackColor = True
        '
        'btEdit
        '
        Me.btEdit.Location = New System.Drawing.Point(288, 25)
        Me.btEdit.Name = "btEdit"
        Me.btEdit.Size = New System.Drawing.Size(86, 56)
        Me.btEdit.TabIndex = 2
        Me.btEdit.Text = "Редактирай"
        Me.btEdit.UseVisualStyleBackColor = True
        '
        'btDelete
        '
        Me.btDelete.Location = New System.Drawing.Point(196, 104)
        Me.btDelete.Name = "btDelete"
        Me.btDelete.Size = New System.Drawing.Size(86, 56)
        Me.btDelete.TabIndex = 3
        Me.btDelete.Text = "Изтриване на текущия елемент"
        Me.btDelete.UseVisualStyleBackColor = True
        '
        'BtClear
        '
        Me.BtClear.Location = New System.Drawing.Point(288, 104)
        Me.BtClear.Name = "BtClear"
        Me.BtClear.Size = New System.Drawing.Size(86, 56)
        Me.BtClear.TabIndex = 4
        Me.BtClear.Text = "Изтриване на всички елементи"
        Me.BtClear.UseVisualStyleBackColor = True
        '
        'BTexit
        '
        Me.BTexit.Location = New System.Drawing.Point(84, 170)
        Me.BTexit.Name = "BTexit"
        Me.BTexit.Size = New System.Drawing.Size(250, 23)
        Me.BTexit.TabIndex = 5
        Me.BTexit.Text = "Изход"
        Me.BTexit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(383, 205)
        Me.Controls.Add(Me.BTexit)
        Me.Controls.Add(Me.BtClear)
        Me.Controls.Add(Me.btDelete)
        Me.Controls.Add(Me.btEdit)
        Me.Controls.Add(Me.btAdd)
        Me.Controls.Add(Me.lxImena)
        Me.Name = "Form1"
        Me.Text = "Списък с диалогова форма"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lxImena As System.Windows.Forms.ListBox
    Friend WithEvents btAdd As System.Windows.Forms.Button
    Friend WithEvents btEdit As System.Windows.Forms.Button
    Friend WithEvents btDelete As System.Windows.Forms.Button
    Friend WithEvents BtClear As System.Windows.Forms.Button
    Friend WithEvents BTexit As System.Windows.Forms.Button

End Class
