﻿Public Class Form1

    Private Sub btMDI_Click(sender As System.Object, e As System.EventArgs) Handles btMDI.Click
        Dim mdiform As New Form2
        mdiform.MdiParent = Me
        mdiform.Show()
    End Sub
End Class
