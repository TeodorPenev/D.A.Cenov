﻿Public Class Form1

    Private Sub btfolder_Click(sender As System.Object, e As System.EventArgs) Handles btfolder.Click
        Dim fbd As New FolderBrowserDialog
        Dim r As DialogResult
        fbd.rootfolder = Environment.SpecialFolder.MyDocuments
        fbd.description = "Изберете папка"
        r = fbd.showdialog
        If r = Windows.Forms.DialogResult.OK Then
            lbtxt.text = fbd.selectedpath

        End If
    End Sub
End Class
