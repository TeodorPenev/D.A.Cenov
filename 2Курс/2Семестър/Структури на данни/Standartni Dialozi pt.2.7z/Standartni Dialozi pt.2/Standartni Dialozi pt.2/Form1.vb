﻿Public Class Form1

    Private Sub btfont_Click(sender As System.Object, e As System.EventArgs) Handles btfont.Click
        Dim fd As New FontDialog
        Dim r As DialogResult

        fd.ShowEffects = True
        fd.ShowColor = True
        fd.MinSize = 10
        fd.MaxSize = 30

        r = fd.ShowDialog

        If r = Windows.Forms.DialogResult.OK Then
            lbtxt.Font = fd.Font
            lbtxt.ForeColor = fd.Color
        End If

    End Sub
End Class
