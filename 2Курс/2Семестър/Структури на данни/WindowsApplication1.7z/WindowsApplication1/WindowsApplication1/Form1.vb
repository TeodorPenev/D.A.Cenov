﻿Public Class Form1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles btfile.Click
        Dim ofd As New OpenFileDialog
        Dim r As DialogResult

        ofd.InitialDirectory = "D:\"
        ofd.Title = "Izberete fail"
        ofd.Filter = "Vsichki|*.*|Dokumenti|*.doc;*.docx;*.txt"
        ofd.FilterIndex = 2
        r = ofd.ShowDialog
        If r = Windows.Forms.DialogResult.OK Then
            lbtxt.text = ofd.FileName
        End If
    End Sub
End Class
