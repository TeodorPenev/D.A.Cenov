﻿namespace HotelServices {
    
    
    public partial class ds {
    }
}

namespace HotelServices.dsTableAdapters {
    
    
    public partial class CustomersTableAdapter {
    }
}
