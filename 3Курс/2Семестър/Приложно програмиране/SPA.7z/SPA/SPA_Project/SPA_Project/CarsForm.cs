﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SPA_Project
{
    public partial class CarsForm : Form

    {
        public string connStringSPA1;
        SqlConnection connSPA;
        DataSet ds;
        SqlDataAdapter daCars;
        SqlCommandBuilder cbCars;
        BindingSource _bindsrc = new BindingSource();
        public CarsForm(string strParam1)
        {
            InitializeComponent();
            connStringSPA1 = strParam1;
        }

        private void CarsForm_Load(object sender, EventArgs e)
        {
            connSPA = new SqlConnection(connStringSPA1);
            connSPA.Open();
            daCars = new SqlDataAdapter("Select * from Cars", connSPA);
            ds = new DataSet();
            cbCars = new SqlCommandBuilder(daCars);
            daCars.Fill(ds, "Cars");
            BindingNavigator _bindnav = new BindingNavigator(true);
            _bindsrc.DataSource = ds.Tables["Cars"];
            _bindnav.BindingSource = _bindsrc;
            dataGridView1.DataSource = _bindsrc;
            bindingNavigator1.BindingSource = _bindsrc;

            connSPA.Close();

            dataGridView1.Columns[0].HeaderText = "ИД код";
            dataGridView1.Columns[1].HeaderText = "Модел автмобил";
            dataGridView1.Columns[2].HeaderText = "Година на излизане";
            dataGridView1.Columns[3].HeaderText = "Брой еърбега";
            dataGridView1.Columns[4].HeaderText = "Цена (лв.)";
            dataGridView1.Columns[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns[3].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns[4].DefaultCellStyle.Format = "n2";
            dataGridView1.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridView1.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }
  

        private void bindingNavigatorLoadItem_Click(object sender, EventArgs e)
        {
            connSPA.Open();
            daCars = new SqlDataAdapter("SELECT * from Cars", connSPA);
            ds = new DataSet();
            cbCars = new SqlCommandBuilder(daCars);
            daCars.Fill(ds, "Cars");
            _bindsrc.DataSource = ds.Tables["Cars"];
            dataGridView1.DataSource = _bindsrc;
            connSPA.Close();
        }

        private void bindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            connSPA.Open();
            daCars.Update(ds, "Cars");
            daCars = new SqlDataAdapter("SELECT * from Cars", connSPA);
            ds = new DataSet();
            cbCars = new SqlCommandBuilder(daCars);
            daCars.Fill(ds, "Cars");
            _bindsrc.DataSource = ds.Tables["Cars"];
            dataGridView1.DataSource = _bindsrc;
            connSPA.Close();
        }
    }
}
