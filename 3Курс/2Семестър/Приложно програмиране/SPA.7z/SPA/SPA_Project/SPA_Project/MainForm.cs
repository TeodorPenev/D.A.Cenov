﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SPA_Project
{
    public partial class MainForm : Form
    {
        string connStringSPA = @"Data Source=THEONE;Initial Catalog=SPA115013;Integrated Security=True";
        string connServer = @"THEONE";
        string connDB = "SPA115013";
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Изход от програмата?", "Потвърждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void моделиАвтомобилиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CarsForm frmCars = new CarsForm(connStringSPA);
            frmCars.ShowDialog();
        }

        private void клиентиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomersForm frmCustomers = new CustomersForm(connStringSPA);
            frmCustomers.ShowDialog();
        }

        private void продажбиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SalesForm frmSales = new SalesForm(connStringSPA);
            frmSales.ShowDialog();
        }
    }
}

