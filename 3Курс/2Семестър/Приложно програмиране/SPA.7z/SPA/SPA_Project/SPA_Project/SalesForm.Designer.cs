﻿namespace SPA_Project
{
    partial class SalesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbSales = new System.Windows.Forms.ToolStrip();
            this.btFirst = new System.Windows.Forms.ToolStripButton();
            this.btPrev = new System.Windows.Forms.ToolStripButton();
            this.btNext = new System.Windows.Forms.ToolStripButton();
            this.btLast = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btNew = new System.Windows.Forms.ToolStripButton();
            this.btDelete = new System.Windows.Forms.ToolStripButton();
            this.btEdit = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btSave = new System.Windows.Forms.ToolStripButton();
            this.btCancel = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btLoad = new System.Windows.Forms.ToolStripButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbCarID = new System.Windows.Forms.TextBox();
            this.tbNote = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbGuaranty = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbCustomerID = new System.Windows.Forms.ComboBox();
            this.tbHowToPay = new System.Windows.Forms.TextBox();
            this.tbAmount = new System.Windows.Forms.TextBox();
            this.tbSaleDate = new System.Windows.Forms.TextBox();
            this.tbSaleNo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbSales.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbSales
            // 
            this.tbSales.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btFirst,
            this.btPrev,
            this.btNext,
            this.btLast,
            this.toolStripSeparator1,
            this.btNew,
            this.btDelete,
            this.btEdit,
            this.toolStripSeparator2,
            this.btSave,
            this.btCancel,
            this.toolStripSeparator3,
            this.btLoad});
            this.tbSales.Location = new System.Drawing.Point(0, 0);
            this.tbSales.Name = "tbSales";
            this.tbSales.Size = new System.Drawing.Size(629, 38);
            this.tbSales.TabIndex = 0;
            this.tbSales.Text = "toolStrip1";
            // 
            // btFirst
            // 
            this.btFirst.AutoSize = false;
            this.btFirst.Image = global::SPA_Project.Properties.Resources.DataContainer_MoveFirstHS;
            this.btFirst.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btFirst.Name = "btFirst";
            this.btFirst.Size = new System.Drawing.Size(60, 35);
            this.btFirst.Text = "първа";
            this.btFirst.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btFirst.ToolTipText = "ппридвижва към първата поръчка";
            this.btFirst.Click += new System.EventHandler(this.btFirst_Click);
            // 
            // btPrev
            // 
            this.btPrev.AutoSize = false;
            this.btPrev.Image = global::SPA_Project.Properties.Resources.DataContainer_MovePreviousHS;
            this.btPrev.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btPrev.Name = "btPrev";
            this.btPrev.Size = new System.Drawing.Size(60, 35);
            this.btPrev.Text = "предна";
            this.btPrev.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btPrev.ToolTipText = "предвижва към предната поръчка";
            this.btPrev.Click += new System.EventHandler(this.btPrev_Click);
            // 
            // btNext
            // 
            this.btNext.AutoSize = false;
            this.btNext.Image = global::SPA_Project.Properties.Resources.DataContainer_MoveNextHS;
            this.btNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btNext.Name = "btNext";
            this.btNext.Size = new System.Drawing.Size(60, 35);
            this.btNext.Text = "следваща";
            this.btNext.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btNext.ToolTipText = "предвижва към следващата поръчка";
            this.btNext.Click += new System.EventHandler(this.btNext_Click);
            // 
            // btLast
            // 
            this.btLast.AutoSize = false;
            this.btLast.Image = global::SPA_Project.Properties.Resources.DataContainer_MoveLastHS;
            this.btLast.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btLast.Name = "btLast";
            this.btLast.Size = new System.Drawing.Size(60, 35);
            this.btLast.Text = "последна";
            this.btLast.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btLast.ToolTipText = "придвижва към последната поръчка";
            this.btLast.Click += new System.EventHandler(this.btLast_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 38);
            // 
            // btNew
            // 
            this.btNew.AutoSize = false;
            this.btNew.Image = global::SPA_Project.Properties.Resources.DataContainer_NewRecordHS;
            this.btNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btNew.Name = "btNew";
            this.btNew.Size = new System.Drawing.Size(60, 35);
            this.btNew.Text = "нова";
            this.btNew.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btNew.ToolTipText = "добавя нова поръчка";
            // 
            // btDelete
            // 
            this.btDelete.AutoSize = false;
            this.btDelete.Image = global::SPA_Project.Properties.Resources.DeleteHS;
            this.btDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btDelete.Name = "btDelete";
            this.btDelete.Size = new System.Drawing.Size(60, 35);
            this.btDelete.Text = "изтрива";
            this.btDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btDelete.ToolTipText = "изтрива текущата поръчка";
            // 
            // btEdit
            // 
            this.btEdit.AutoSize = false;
            this.btEdit.Image = global::SPA_Project.Properties.Resources.EditTableHS;
            this.btEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btEdit.Name = "btEdit";
            this.btEdit.Size = new System.Drawing.Size(60, 35);
            this.btEdit.Text = "промяна";
            this.btEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btEdit.ToolTipText = "променя текущата поръчка";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 38);
            // 
            // btSave
            // 
            this.btSave.AutoSize = false;
            this.btSave.Image = global::SPA_Project.Properties.Resources.saveHS;
            this.btSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btSave.Name = "btSave";
            this.btSave.Size = new System.Drawing.Size(60, 35);
            this.btSave.Text = "запис";
            this.btSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btSave.ToolTipText = "записване на направените промени";
            // 
            // btCancel
            // 
            this.btCancel.AutoSize = false;
            this.btCancel.Image = global::SPA_Project.Properties.Resources.Delete_tableHS;
            this.btCancel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(60, 35);
            this.btCancel.Text = "отказ";
            this.btCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btCancel.ToolTipText = "отказ от направените промени";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 38);
            // 
            // btLoad
            // 
            this.btLoad.AutoSize = false;
            this.btLoad.Image = global::SPA_Project.Properties.Resources.RefreshDocViewHS;
            this.btLoad.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btLoad.Name = "btLoad";
            this.btLoad.Size = new System.Drawing.Size(60, 35);
            this.btLoad.Text = "зареди";
            this.btLoad.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btLoad.ToolTipText = "зареждане на таблицата на сървъра";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tbCarID);
            this.panel1.Controls.Add(this.tbNote);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.tbGuaranty);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.cbCustomerID);
            this.panel1.Controls.Add(this.tbHowToPay);
            this.panel1.Controls.Add(this.tbAmount);
            this.panel1.Controls.Add(this.tbSaleDate);
            this.panel1.Controls.Add(this.tbSaleNo);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 41);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(629, 375);
            this.panel1.TabIndex = 1;
            // 
            // tbCarID
            // 
            this.tbCarID.AllowDrop = true;
            this.tbCarID.Location = new System.Drawing.Point(73, 73);
            this.tbCarID.Name = "tbCarID";
            this.tbCarID.Size = new System.Drawing.Size(100, 20);
            this.tbCarID.TabIndex = 18;
            // 
            // tbNote
            // 
            this.tbNote.Location = new System.Drawing.Point(73, 131);
            this.tbNote.MaxLength = 40;
            this.tbNote.Name = "tbNote";
            this.tbNote.Size = new System.Drawing.Size(100, 20);
            this.tbNote.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(0, 134);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Забележка:";
            // 
            // tbGuaranty
            // 
            this.tbGuaranty.Location = new System.Drawing.Point(252, 131);
            this.tbGuaranty.Name = "tbGuaranty";
            this.tbGuaranty.Size = new System.Drawing.Size(100, 20);
            this.tbGuaranty.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(179, 125);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 26);
            this.label8.TabIndex = 14;
            this.label8.Text = "Гаранционно \r\nподържане:";
            // 
            // cbCustomerID
            // 
            this.cbCustomerID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCustomerID.FormattingEnabled = true;
            this.cbCustomerID.Location = new System.Drawing.Point(252, 70);
            this.cbCustomerID.Name = "cbCustomerID";
            this.cbCustomerID.Size = new System.Drawing.Size(100, 21);
            this.cbCustomerID.TabIndex = 13;
            // 
            // tbHowToPay
            // 
            this.tbHowToPay.Location = new System.Drawing.Point(73, 102);
            this.tbHowToPay.Name = "tbHowToPay";
            this.tbHowToPay.Size = new System.Drawing.Size(100, 20);
            this.tbHowToPay.TabIndex = 11;
            // 
            // tbAmount
            // 
            this.tbAmount.Location = new System.Drawing.Point(252, 102);
            this.tbAmount.Name = "tbAmount";
            this.tbAmount.ReadOnly = true;
            this.tbAmount.Size = new System.Drawing.Size(100, 20);
            this.tbAmount.TabIndex = 10;
            // 
            // tbSaleDate
            // 
            this.tbSaleDate.Location = new System.Drawing.Point(252, 41);
            this.tbSaleDate.Name = "tbSaleDate";
            this.tbSaleDate.Size = new System.Drawing.Size(100, 20);
            this.tbSaleDate.TabIndex = 8;
            // 
            // tbSaleNo
            // 
            this.tbSaleNo.Location = new System.Drawing.Point(73, 41);
            this.tbSaleNo.Name = "tbSaleNo";
            this.tbSaleNo.Size = new System.Drawing.Size(100, 20);
            this.tbSaleNo.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(0, 96);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 26);
            this.label7.TabIndex = 6;
            this.label7.Text = "Начин \r\nна плащане:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(179, 105);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Цена:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(179, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Клиент:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Модел:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(179, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Дата:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Код:";
            // 
            // SalesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 417);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tbSales);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SalesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Продажби";
            this.Load += new System.EventHandler(this.SalesForm_Load);
            this.tbSales.ResumeLayout(false);
            this.tbSales.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip tbSales;
        private System.Windows.Forms.ToolStripButton btFirst;
        private System.Windows.Forms.ToolStripButton btPrev;
        private System.Windows.Forms.ToolStripButton btNext;
        private System.Windows.Forms.ToolStripButton btLast;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btNew;
        private System.Windows.Forms.ToolStripButton btDelete;
        private System.Windows.Forms.ToolStripButton btEdit;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btSave;
        private System.Windows.Forms.ToolStripButton btCancel;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton btLoad;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tbNote;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbGuaranty;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbCustomerID;
        private System.Windows.Forms.TextBox tbHowToPay;
        private System.Windows.Forms.TextBox tbAmount;
        private System.Windows.Forms.TextBox tbSaleDate;
        private System.Windows.Forms.TextBox tbSaleNo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbCarID;
    }
}