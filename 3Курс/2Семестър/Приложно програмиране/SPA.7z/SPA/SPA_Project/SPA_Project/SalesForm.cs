﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SPA_Project
{
    public partial class SalesForm : Form
    {
        public string connStringSPA1;
        private CurrencyManager myCurrencyManager;
        SqlConnection connSPA;
        DataSet ds;
        SqlDataAdapter daSales, daCars, daCustomers;
        SqlCommandBuilder cbSales;
        string sql;
        public SalesForm(string strParam1)
        {
            InitializeComponent();
            connStringSPA1 = strParam1;
        }
        protected void CurrencyToString(object sender, ConvertEventArgs e)
        {
            if (e.DesiredType != typeof(string))
            {
                return;
            }
            try
            {
                e.Value = ((decimal)(e.Value)).ToString("#########0.00");
            }
            catch (Exception)
            {
                e.Value = "";
            }
        }
        ////private void SetAmount()
        ////{
        ////    string carPrice = "";
        ////    decimal amountOrder;
        ////    sql = "SELECT Price FROM Cars WHERE CarID = '" + cbCarID.SelectedValue + "'";
        ////    connSPA = new SqlConnection(connStringSPA1);
        ////    connSPA.Open();
        ////    DataSet ds1;
        ////    ds1 = new DataSet();
        ////    SqlDataAdapter da1;
        ////    da1 = new SqlDataAdapter(sql, connSPA);
        ////    da1.Fill(ds1, "CarsPrice");
        ////    if (ds1.Tables["CarsPrice"].Rows.Count != 0)
        ////    {
        ////        carPrice = ds1.Tables["CarPrice"].Rows[0]["Price"].ToString();
        ////    }
        ////    try
        ////    {
        ////        amountOrder = (Convert.ToDecimal(carPrice));
        ////    }
        ////    catch (Exception)
        ////    {
        ////        amountOrder = 0;
        ////    }
        ////    tbAmount.Text = amountOrder.ToString("#########0.00");
        ////    connSPA.Close();
        ////    connSPA.Dispose();

        ////    ds1.Dispose();
        ////    da1.Dispose();

        ////}
        protected void DateToString(object sender, ConvertEventArgs e)
        {
            if (e.DesiredType != typeof(string))
            {
                return;
            }
            try
            {
                e.Value = ((DateTime)(e.Value)).ToString("dd.MM.yyyy");
            }
            catch
            {
                e.Value = "";
            }
        }
        private void SetStateNavigationButtons()
        {
            this.btFirst.Enabled = true;
            this.btPrev.Enabled = true;
            this.btNext.Enabled = true;
            this.btLast.Enabled = true;
            if (myCurrencyManager.Count == 0)
            {
                this.btFirst.Enabled = false;
                this.btPrev.Enabled = false;
                this.btNext.Enabled = false;
                this.btLast.Enabled = false;
                return;
            }
            if (myCurrencyManager.Position == 0)
            {
                this.btFirst.Enabled = false;
                this.btPrev.Enabled = false;
                return;
            }
            if (myCurrencyManager.Position == myCurrencyManager.Count - 1)
            {
                this.btNext.Enabled = false;
                this.btLast.Enabled = false;
                return;
            }
        }
        private void Current_Changed(object sender, EventArgs e)
        {
            SetStateNavigationButtons();
        }
        private void CurrencyManager_ItemChanged(object sender, System.Windows.Forms.ItemChangedEventArgs e)
        {
            SetStateNavigationButtons();
        }
        private void Position_Changed(Object sender, EventArgs e)
        {
            SetStateNavigationButtons();
        }

        private void SalesForm_Load(object sender, EventArgs e)
        {
            connSPA = new SqlConnection(connStringSPA1);
            connSPA.Open();
            ds = new DataSet();
            daCars = new SqlDataAdapter("select * from Cars", connSPA);
            daCustomers = new SqlDataAdapter("select * from Customers", connSPA);
            daSales = new SqlDataAdapter("select * from Sales", connSPA);
            cbSales = new SqlCommandBuilder(daSales);
            daCars.Fill(ds, "Cars");
            daCustomers.Fill(ds, "Customers");
            daSales.Fill(ds, "Sales");
            tbSaleNo.DataBindings.Add("Text", ds.Tables["Sales"], "SaleID");
            Binding UnitSaleDataBinding = new Binding("Text", ds.Tables["Sales"], "SaleDate");
            UnitSaleDataBinding.Format += new System.Windows.Forms.ConvertEventHandler(DateToString);
            tbSaleDate.DataBindings.Add(UnitSaleDataBinding);
            tbCarID.DataBindings.Add("Text", ds.Tables["Sales"], "CarID");
            cbCustomerID.DataSource = ds.Tables["Customers"];
            cbCustomerID.DisplayMember = "CustomerFullName";
            cbCustomerID.ValueMember = "CustomersID";
            cbCustomerID.DataBindings.Add(new Binding("SelectedValue", ds.Tables["Sales"], "CustomersID"));
            tbHowToPay.DataBindings.Add("Text", ds.Tables["Sales"], "HowToPay");
            Binding UnitAmountBinding = new Binding("Text", ds.Tables["Sales"], "Price");
            UnitAmountBinding.Format += new System.Windows.Forms.ConvertEventHandler(CurrencyToString);
            tbAmount.DataBindings.Add(UnitAmountBinding);
            tbNote.DataBindings.Add("Text", ds.Tables["Sales"], "Note");
            tbGuaranty.DataBindings.Add("Text", ds.Tables["Sales"], "Guarantee");
            connSPA.Close();

            myCurrencyManager = (CurrencyManager)this.BindingContext[ds.Tables["Sales"]];
            myCurrencyManager.CurrentChanged += new EventHandler(Current_Changed);
            myCurrencyManager.ItemChanged += new ItemChangedEventHandler(CurrencyManager_ItemChanged);
            myCurrencyManager.PositionChanged += new EventHandler(Position_Changed);
            if (myCurrencyManager.Count > 0)
                myCurrencyManager.Position = myCurrencyManager.Count - 1;
            SetStateNavigationButtons();
            btSave.Enabled = false;
            btCancel.Enabled = false;

        }

        private void btFirst_Click(object sender, EventArgs e)
        {
            if (myCurrencyManager.Position != 0)
                myCurrencyManager.Position = 0;
        }

        private void btPrev_Click(object sender, EventArgs e)
        {
            if (myCurrencyManager.Position > 0)
                myCurrencyManager.Position -= 1;
        }

        private void btNext_Click(object sender, EventArgs e)
        {
            if (myCurrencyManager.Position < myCurrencyManager.Count)
                myCurrencyManager.Position += 1;
        }

        private void btLast_Click(object sender, EventArgs e)
        {
            if (myCurrencyManager.Position < myCurrencyManager.Count - 1)
                myCurrencyManager.Position = myCurrencyManager.Count - 1;
        }

    }
}



