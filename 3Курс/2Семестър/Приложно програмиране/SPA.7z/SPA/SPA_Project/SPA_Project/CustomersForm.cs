﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SPA_Project
{
    public partial class CustomersForm : Form
    {
        public string connStringSPA1;
        SqlConnection connSPA;
        DataSet ds;
        SqlDataAdapter daCustomers;
        SqlCommandBuilder cbCustomers;
        BindingSource _bindsrc = new BindingSource();
        public CustomersForm(string strParam1)
        {
            InitializeComponent();
            connStringSPA1 = strParam1;
        }

        private void CustomersForm_Load(object sender, EventArgs e)
        {
            connSPA = new SqlConnection(connStringSPA1);
            connSPA.Open();
            daCustomers = new SqlDataAdapter("Select * from Customers", connSPA);
            ds = new DataSet();
            cbCustomers = new SqlCommandBuilder(daCustomers);
            daCustomers.Fill(ds, "Customers");
            BindingNavigator _bindnav = new BindingNavigator(true);
            _bindsrc.DataSource = ds.Tables["Customers"];
            _bindnav.BindingSource = _bindsrc;
            dataGridView1.DataSource = _bindsrc;
            bindingNavigator1.BindingSource = _bindsrc;

            connSPA.Close();

            dataGridView1.Columns[0].HeaderText = "ИД код";
            dataGridView1.Columns[1].HeaderText = "Трите имена";
            dataGridView1.Columns[2].HeaderText = "Адрес";
            dataGridView1.Columns[3].HeaderText = "Телефонен номер";
            dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
        }
  

        private void bindingNavigatorLoadItem_Click(object sender, EventArgs e)
        {
            connSPA.Open();
            daCustomers = new SqlDataAdapter("SELECT * from Customers", connSPA);
            ds = new DataSet();
            cbCustomers = new SqlCommandBuilder(daCustomers);
            daCustomers.Fill(ds, "Customers");
            _bindsrc.DataSource = ds.Tables["Customers"];
            dataGridView1.DataSource = _bindsrc;
            connSPA.Close();
        }

        private void bindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            connSPA.Open();
            daCustomers.Update(ds, "Customers");
            daCustomers = new SqlDataAdapter("SELECT * from Customers", connSPA);
            ds = new DataSet();
            cbCustomers = new SqlCommandBuilder(daCustomers);
            daCustomers.Fill(ds, "Customers");
            _bindsrc.DataSource = ds.Tables["Customers"];
            dataGridView1.DataSource = _bindsrc;
            connSPA.Close();
        }


    }
}