﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lbTime = New System.Windows.Forms.Label()
        Me.cbAlarm = New System.Windows.Forms.CheckBox()
        Me.timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'lbTime
        '
        Me.lbTime.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.lbTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lbTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.lbTime.ForeColor = System.Drawing.Color.Blue
        Me.lbTime.Location = New System.Drawing.Point(12, 28)
        Me.lbTime.Name = "lbTime"
        Me.lbTime.Size = New System.Drawing.Size(248, 69)
        Me.lbTime.TabIndex = 0
        Me.lbTime.Text = "00:00"
        Me.lbTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cbAlarm
        '
        Me.cbAlarm.AutoSize = True
        Me.cbAlarm.ForeColor = System.Drawing.Color.Yellow
        Me.cbAlarm.Location = New System.Drawing.Point(195, 8)
        Me.cbAlarm.Name = "cbAlarm"
        Me.cbAlarm.Size = New System.Drawing.Size(65, 17)
        Me.cbAlarm.TabIndex = 1
        Me.cbAlarm.Text = "Аларма"
        Me.cbAlarm.UseVisualStyleBackColor = True
        '
        'timer1
        '
        Me.timer1.Enabled = True
        Me.timer1.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(275, 119)
        Me.Controls.Add(Me.cbAlarm)
        Me.Controls.Add(Me.lbTime)
        Me.Name = "Form1"
        Me.Text = "Часовник"
        Me.TransparencyKey = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbTime As System.Windows.Forms.Label
    Friend WithEvents cbAlarm As System.Windows.Forms.CheckBox
    Friend WithEvents timer1 As System.Windows.Forms.Timer

End Class
