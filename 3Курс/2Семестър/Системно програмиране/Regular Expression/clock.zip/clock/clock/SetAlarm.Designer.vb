﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SetAlarm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.dtpAlarm = New System.Windows.Forms.DateTimePicker()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Button1.Location = New System.Drawing.Point(25, 38)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(48, 31)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "OK"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button2.Location = New System.Drawing.Point(97, 38)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(48, 31)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Отказ"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'dtpAlarm
        '
        Me.dtpAlarm.CustomFormat = "dd.MM.yyyy HH:mm:ss"
        Me.dtpAlarm.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpAlarm.Location = New System.Drawing.Point(12, 12)
        Me.dtpAlarm.Name = "dtpAlarm"
        Me.dtpAlarm.Size = New System.Drawing.Size(145, 20)
        Me.dtpAlarm.TabIndex = 4
        '
        'SetAlarm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(169, 82)
        Me.Controls.Add(Me.dtpAlarm)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "SetAlarm"
        Me.Text = "Задайте аларма"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents dtpAlarm As System.Windows.Forms.DateTimePicker
End Class
