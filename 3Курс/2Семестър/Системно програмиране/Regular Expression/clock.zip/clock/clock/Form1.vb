﻿Public Class Form1
    'Текуща аларма
    Dim alarm As Date = #1/1/2011#

    ' Подготовка на контрола Timer при стартиране 
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        timer1.Enabled = True ' "Пуска" се таймера
        timer1.Interval = 1000 ' една секунда
    End Sub
    ' Когато се промени състоянието на CheckBox контрола
    Private Sub cbAlarm_CheckedChanged(sender As Object, e As System.EventArgs) Handles cbAlarm.CheckedChanged
        Dim sa As New SetAlarm ' Променлива от тип форма SetAlarm
        ' Ако включваме алармата
        If cbAlarm.Checked Then
            ' Ако вече има някаква аларма
            If alarm <> #1/1/2011# Then
                sa.dtpAlarm.Value = alarm ' Прехвърляме във формата
            End If
            ' Показваме формата и ако резултата е ОК
            If sa.ShowDialog = Windows.Forms.DialogResult.OK Then
                alarm = sa.dtpAlarm.Value 'Вземаме от формата новата аларма
                ' Показваме алармата и в заглавния ред на формата
                Me.Text = "Часовник (" & alarm.ToString("HH:mm:ss") & ")"
            End If
        Else 'Ако изключваме алармата
            Me.Text = "Часовник" 'Нормализираме надписа на формата
        End If

    End Sub
    ' Събитие което се изпълнява всяка секунда
    Private Sub timer1_Tick(sender As Object, e As System.EventArgs) Handles timer1.Tick
        'Показваме часа
        lbTime.Text = Date.Now.ToString("HH:mm:ss")
        'Ако алармата е включена И съвпада с текущия час
        If cbAlarm.Checked AndAlso Date.Now.ToString = alarm.ToString Then
            cbAlarm.Checked = False ' Изключваме
            ' Издаваме звук и показваме надпис
            My.Computer.Audio.PlaySystemSound(Media.SystemSounds.Beep)
            MessageBox.Show("Аларма!")
        End If
    End Sub
    
End Class
