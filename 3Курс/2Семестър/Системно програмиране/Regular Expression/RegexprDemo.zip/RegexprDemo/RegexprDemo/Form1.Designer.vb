﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tvResult = New System.Windows.Forms.TreeView()
        Me.btStart = New System.Windows.Forms.Button()
        Me.lbRegExp = New System.Windows.Forms.Label()
        Me.tbExp = New System.Windows.Forms.TextBox()
        Me.lbExp = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'tvResult
        '
        Me.tvResult.Location = New System.Drawing.Point(18, 94)
        Me.tvResult.Name = "tvResult"
        Me.tvResult.Size = New System.Drawing.Size(258, 307)
        Me.tvResult.TabIndex = 0
        '
        'btStart
        '
        Me.btStart.Location = New System.Drawing.Point(60, 37)
        Me.btStart.Name = "btStart"
        Me.btStart.Size = New System.Drawing.Size(161, 30)
        Me.btStart.TabIndex = 1
        Me.btStart.Text = "Анализ"
        Me.btStart.UseVisualStyleBackColor = True
        '
        'lbRegExp
        '
        Me.lbRegExp.AutoSize = True
        Me.lbRegExp.Location = New System.Drawing.Point(32, 70)
        Me.lbRegExp.Name = "lbRegExp"
        Me.lbRegExp.Size = New System.Drawing.Size(42, 13)
        Me.lbRegExp.TabIndex = 2
        Me.lbRegExp.Text = "Израз:"
        '
        'tbExp
        '
        Me.tbExp.Location = New System.Drawing.Point(60, 11)
        Me.tbExp.Name = "tbExp"
        Me.tbExp.Size = New System.Drawing.Size(212, 20)
        Me.tbExp.TabIndex = 3
        Me.tbExp.Text = "dddabcabcabc345jew"
        '
        'lbExp
        '
        Me.lbExp.AutoSize = True
        Me.lbExp.Location = New System.Drawing.Point(15, 14)
        Me.lbExp.Name = "lbExp"
        Me.lbExp.Size = New System.Drawing.Size(42, 13)
        Me.lbExp.TabIndex = 4
        Me.lbExp.Text = "Израз:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 413)
        Me.Controls.Add(Me.lbExp)
        Me.Controls.Add(Me.tbExp)
        Me.Controls.Add(Me.lbRegExp)
        Me.Controls.Add(Me.btStart)
        Me.Controls.Add(Me.tvResult)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tvResult As System.Windows.Forms.TreeView
    Friend WithEvents btStart As System.Windows.Forms.Button
    Friend WithEvents lbRegExp As System.Windows.Forms.Label
    Friend WithEvents tbExp As System.Windows.Forms.TextBox
    Friend WithEvents lbExp As System.Windows.Forms.Label

End Class
