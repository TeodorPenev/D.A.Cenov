﻿Imports System.Text.RegularExpressions
Public Class Form1
    Dim regex As String = "(abc)+(\d+)"

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lbRegExp.Text = "Регулярен израз:" & regex
    End Sub

    Private Sub btStart_Click(sender As Object, e As EventArgs) Handles btStart.Click
        tvResult.Nodes.Clear()
        Dim r As New Regex(regex)
        Dim m As Match
        Dim tn As TreeNode
        Dim gbr, cbr As Long
        gbr = 0
        m = r.Match(tbExp.Text)

        tn = tvResult.Nodes.Add("Match:" & m.Value & "-> позиция:" & m.Index)
        tn = tn.Nodes.Add("Groups")
        For Each g As Group In m.Groups
            tn = tn.Nodes.Add("№" & gbr & " : " & g.Value & "-> позиция: " & g.Index)
            cbr = 0
            tn = tn.Nodes.Add("Captures")
            For Each c As Capture In g.Captures
                tn.Nodes.Add("№" & cbr & " : " & c.Value & "-> позиция:" & c.Index)
                cbr += 1
            Next
            tn = tn.Parent.Parent
            gbr += 1
        Next
    End Sub
End Class
