﻿Public Class Form1

    ' Бутон за начало на сърфирането
    Private Sub btGo_Click(sender As System.Object, e As System.EventArgs) Handles btGo.Click
        Dim address As String = tbUrl.Text
        If address = "" Then ' Ако адресната лента е празна отива на 
            ' "домашната" страница
            wb1.GoHome()
        Else
            'Ако адресът е зададен без "http" или "https"
            'допълва със Http
            If Not address.StartsWith("http://") And _
               Not address.StartsWith("https://") Then
                address = "http://" & address
            End If

            Try
                ' Старт на навигацията
                wb1.Navigate(address)
            Catch ex As System.UriFormatException
                ' Ако има грешка я игнорира
                Return
            End Try
        End If

    End Sub
    ' Когато започне зареждането на нова страница 
    Private Sub wb1_Navigated(sender As Object, e As System.Windows.Forms.WebBrowserNavigatedEventArgs) Handles wb1.Navigated
        tbUrl.Text = wb1.Url.ToString ' Сменя стойността на полето с новия адрес
    End Sub
    ' Когато зареждането приключи
    Private Sub wb1_DocumentCompleted(sender As Object, e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles wb1.DocumentCompleted
        ' Тук може да се използват свойствата
        ' Document - Целия HTМL документ
        ' DocumentText - документа във вид на текст
        ' за различни анализи и обработки
        ' Пример:
        ' Взема целия документ и използва тага Title (разгледайте свойствата на HTMLDocument класа)
        Dim d As HtmlDocument = wb1.Document
        Me.Text = "WB Demo-" & d.Title ' Сменя заглавието на формата
    End Sub
    

    ' При промяна информацията за прогреса
    Private Sub wb1_ProgressChanged(sender As Object, e As System.Windows.Forms.WebBrowserProgressChangedEventArgs) Handles wb1.ProgressChanged
        ' Необходими проверки защото понякога информацията не е коректна!
        If e.MaximumProgress > 0 AndAlso e.CurrentProgress > -1 And e.MaximumProgress >= e.CurrentProgress Then
            pb1.Maximum = e.MaximumProgress
            pb1.Value = e.CurrentProgress
        End If
    End Sub

    ' Елемента от менюто Exit
    Private Sub tsmiExit_Click(sender As Object, e As System.EventArgs) Handles tsmiExit.Click
        Me.Close()
    End Sub
    ' Елемента от менюто Home
    Private Sub tsmiHome_Click(sender As Object, e As System.EventArgs) Handles tsmiHome.Click
        wb1.GoHome()
    End Sub
    ' Елемента от менюто Print
    Private Sub tsmiPrint_Click(sender As Object, e As System.EventArgs) Handles tsmiPrint.Click
        wb1.Print()
    End Sub
    ' Елемента от менюто Страница за търсене
    Private Sub tsmiSearch_Click(sender As Object, e As System.EventArgs) Handles tsmiSearch.Click
        wb1.GoSearch()
    End Sub
    ' Бутон за връщане
    Private Sub btBack_Click(sender As System.Object, e As System.EventArgs) Handles btBack.Click
        wb1.GoBack()

    End Sub
End Class

